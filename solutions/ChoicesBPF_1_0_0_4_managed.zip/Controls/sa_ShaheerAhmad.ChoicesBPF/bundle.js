/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./ChoicesBPF/index.ts":
/*!*****************************!*\
  !*** ./ChoicesBPF/index.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.ChoicesBPF = void 0;\nvar ChoicesBPF = /** @class */function () {\n  function ChoicesBPF() {}\n  ChoicesBPF.prototype.init = function (context, notifyOutputChanged, state, container) {\n    var _a;\n    this.context = context;\n    this.notifyOutputChanged = notifyOutputChanged;\n    this.container = container;\n    var timelineContainer = document.createElement(\"div\");\n    timelineContainer.classList.add(\"timeline\");\n    this.container.appendChild(timelineContainer);\n    var outerContainer = document.createElement(\"div\");\n    outerContainer.classList.add(\"outer\");\n    timelineContainer.appendChild(outerContainer);\n    var choices = (_a = context.parameters.Choice.attributes) === null || _a === void 0 ? void 0 : _a.Options;\n    var selectedValue = this.context.parameters.Choice.raw;\n    console.log(selectedValue);\n    if (choices != undefined) {\n      choices.forEach(function (item, index) {\n        var card = document.createElement(\"div\");\n        card.classList.add(\"card\");\n        var infoContainer = document.createElement(\"div\");\n        infoContainer.classList.add(\"info\");\n        var title = document.createElement(\"h3\");\n        title.classList.add(\"title\");\n        title.innerText = item.Label;\n        if (item.Value == selectedValue) {\n          infoContainer.classList.add(\"active\");\n          title.classList.add(\"active\");\n        }\n        infoContainer.appendChild(title);\n        card.appendChild(infoContainer);\n        outerContainer.appendChild(card);\n        card.addEventListener('click', function () {\n          document.querySelectorAll('.title').forEach(function (card) {\n            card.classList.remove('active');\n          });\n          document.querySelectorAll('.info').forEach(function (card) {\n            card.classList.remove('active');\n          });\n          title.classList.add('active');\n          infoContainer.classList.add('active');\n          context.parameters.Choice.raw = item.Value;\n          notifyOutputChanged();\n        });\n      });\n    }\n  };\n  ChoicesBPF.prototype.updateView = function (context) {\n    // Add code to update control view\n  };\n  ChoicesBPF.prototype.getOutputs = function () {\n    var _a;\n    return {\n      Choice: (_a = this.context.parameters.Choice.raw) !== null && _a !== void 0 ? _a : undefined\n    };\n  };\n  ChoicesBPF.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n  };\n  return ChoicesBPF;\n}();\nexports.ChoicesBPF = ChoicesBPF;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ChoicesBPF/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./ChoicesBPF/index.ts"](0, __webpack_exports__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('ShaheerAhmad.ChoicesBPF', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ChoicesBPF);
} else {
	var ShaheerAhmad = ShaheerAhmad || {};
	ShaheerAhmad.ChoicesBPF = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ChoicesBPF;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}